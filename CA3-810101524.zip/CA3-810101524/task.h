#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int task(char* input){
    int counter=0;
    char taskname[10];
    int taskNumber=0; //using taskNumber to define what user wants to do
    while((input[counter])!=' '){
        taskname[counter]=input[counter];
        counter++;
    }
    taskname[counter]='\0';
    if(strcmp("signup",taskname)==0){
        taskNumber=1;
    }
    if(strcmp("login",taskname)==0){
        taskNumber=2;
    }
    if(strcmp("post",taskname)==0){
        taskNumber=3;
    }
    if(strcmp("like",taskname)==0){
        taskNumber=4;
    }
    if(strcmp("logout",taskname)==0){
        taskNumber=5;
    }
    if(strcmp("delete",taskname)==0){
        taskNumber=6;
    }
    if(strcmp("info",taskname)==0){
        taskNumber=7;
    }
    if(strcmp("find_user",taskname)==0){
        taskNumber=8;
    }
    return taskNumber;
}