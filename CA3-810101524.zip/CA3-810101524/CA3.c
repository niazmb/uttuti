#include <stdio.h>
#include <stdlib.h>
#include "task.h"
#include "functions.h"
#define USERNAME_SIZE 32
#define PASSWORD_SIZE 32
// using typedef to use simple names for convenience
typedef struct postStruct{  //making a struct for each post.
    char* username;  
    int* post_id;
    int* like_number;
    char* post_text;
}post;
int main(){
while(1){
    int countertask=0;
    char* input; // input includes the task the username and the password if needed.
    input=(char *)malloc(sizeof(char)*(countertask+1));
    do{ //using do-while because we want to get the first char and then check if we have reached space
        input[countertask]=getchar();
        countertask++;
        input = (char *)realloc(input,sizeof(char)*(countertask+1));
    }while((input[countertask-1])!=' ');
    input[countertask]='\0';
    if(task(input)==0){  //saying if such command doesn't exist 
        printf("Wrong input! Such command doesn't exist.\n");
    }
    if(task(input)==1){ //signing up using un and pw
        user *user1=signup(input, countertask);
        printf("New account { %s} has been created. Your password is:%s\n", user1->username, user1->password);
        }
    if(task(input)==2){ //logging in using un and pw
        user *user1=signup(input, countertask);
        if(login(input, countertask)==1){ //if un and ps are correct
            printf("User %s logged in successfully.\n", user1->username);
        }
        else{
            printf("Incorrect username or password.\n");
        }
    }
    free(input);
    }
    return 0;
}