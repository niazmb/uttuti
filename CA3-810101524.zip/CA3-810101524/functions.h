#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct userStruct{  //making a struct for each post.
    char* username;
    char* password;
}user;
struct userStruct *signup(char* input,int counter){
    struct userStruct* user1=(user*)malloc(sizeof(user));
    int i=0;
    char* usernametemp=(char *)malloc(sizeof(char)*(1));
    do{  // using do-while because we want to get the first character and then check if we have reached space
        //printf("%d", counter);
        usernametemp[i]=getchar();
        //counter++;
        i++;
        usernametemp= (char *)realloc(usernametemp,sizeof(char)*(i+1));
    }while((usernametemp[i-1])!=' ');
    usernametemp[i]='\0';
    user1->username=(char*)malloc(strlen(usernametemp));
    strcpy(user1->username,usernametemp);
    int j=0;
    char* passwordtemp=(char *)malloc(sizeof(char)*(j+1));
    do{  // using do-while because we want to get the first character and then check if we have reached enter
        passwordtemp[j]=getchar();
        j++;
        passwordtemp= (char *)realloc(passwordtemp,sizeof(char)*(j+1));
    }while((passwordtemp[j-1])!='\n');
    passwordtemp[j]='\0';
    user1->password=(char*)malloc(strlen(passwordtemp));
    strcpy(user1->password,passwordtemp);
    return user1;
}
int login(char* input,int counter){
    int i=0;
    int countertask=0;
    char* usernameacc=(char *)malloc(sizeof(char)*(1));
    user *user1=signup(input, countertask);
    do{  // using do-while because we want to get the first character and then check if we have reached space
        usernameacc[i]=getchar();
        i++;
        usernameacc= (char *)realloc(usernameacc,sizeof(char)*(i+1));
    }while((usernameacc[i-1])!=' ');
    usernameacc[i]='\0';
    int j=0;
    //printf("HI");
    char* passwordacc=(char *)malloc(sizeof(char)*(j+1));
    do{
        passwordacc[j]=getchar();
        j++;
        passwordacc= (char *)realloc(passwordacc,sizeof(char)*(j+1));
    }while((passwordacc[j-1])!='\n');
    passwordacc[j]='\0'; 
    
    // checking if the username and password exist and are correct

    if((strcmp(user1->username,usernameacc)==0)&&(strcmp(user1->password,passwordacc)==0)){ 
        return 1;
    }
    else{
        return 0;
    }
}